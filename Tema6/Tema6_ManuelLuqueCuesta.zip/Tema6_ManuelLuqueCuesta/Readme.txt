La funcion requerida en el ejercicio 2.1 es discretaFourier, animarSumaParcial es un ejemplo de su uso.
Los ejercicios 3.1 y 4.1 tienen sus respectivos nombres.
Los ejercicios 8.1 y 8.2 se encuentran en ej_filtro.m y ej_telefono.m, respectivamente.