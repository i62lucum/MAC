function amplitudes(c)

dibujarDiagrama(abs(c), 'Amplitudes');

end