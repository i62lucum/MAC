
%Se obtienen A
A=vandermondeF(4);
%Para que A sea correcta, la multiplicacion de esta por su adjunta debe dar
%N por la Identidad. En este caso N=4.
abs(A*A')
