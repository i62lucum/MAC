function y=senyal(t)

y=sign(cos(2*pi*t/6));

end