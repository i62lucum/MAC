function fases(c)

dibujarDiagrama(angle(c),'Fases')

end