function y=ejercicio4(x)

y=10*abs(x);

end