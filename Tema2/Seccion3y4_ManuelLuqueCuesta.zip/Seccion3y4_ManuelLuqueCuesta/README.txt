-Hay una prueba de ejemplo para nodos de chebyshev sobre el ejercicio 4 en el fichero NodosEjercicio4.m
	(Abrir y ejecutar dicho fichero, comentando y descomentando las últimas líneas correspondientes a gráficas para una mejor visualización)
-Hay dos pruebas para regresión: RegresionCubica.m y RegresionLineal.m, las funciones requeridas se encuentran explicadas en
los respectivos ficheros: regresion_minimos, minimos_cuadrados y nodos_chebyshev.