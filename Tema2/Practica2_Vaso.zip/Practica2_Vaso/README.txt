La función principal es vaso3D_din, la cual recibe opcion que:
	0 -> Para curvas de splines
	1 -> Para curvas de bezier.

Esta función se encarga de crear una figura geométrica por revolución de la curva generada, mediante 
la insercción de puntos de manera gráfica por parte del usuario. Además, permite modificar los puntos
arrastrandolos.