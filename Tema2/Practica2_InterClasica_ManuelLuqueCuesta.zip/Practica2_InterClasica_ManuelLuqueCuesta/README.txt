Cada uno de los apartados tiene un fichero de ejecución de prueba, además,
se añaden todas las funciones necesarias para su funcionamiento, incorporando
funciones readaptadas para el polinomio de diferencias divididas de modo que se pueda
reaprovechar la matriz de las diferencias del polinomio anterior.