Se han desarrollado una serie de ficheros de prueba para probar el correcto funcionamiento:
    -LinealPrueba.m -> Para splines lineales.
    -CubicoPrueba.m -> Para splines cubicos.
    -CurvaSplinePrueba.m -> Para curvas de splines, introduciendo puntos por pantalla.
Para la curva de bezier, se encuentra la funci�n curva_bezier que pide los puntos por pantalla
y recibe como paramentro el numero de intervalos N, siendo N+1 los puntos a introducir.