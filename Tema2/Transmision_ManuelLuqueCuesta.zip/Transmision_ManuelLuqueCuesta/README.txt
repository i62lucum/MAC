Mejoras añadidas:
	- Probabilidad de ser contagiado, recibido como argumento del programa.
	- Tiempo de recuperación, recibido como argumento del programa.
	- Probabilidad de que una partícula sea aíslada (aquellas inamovibles, pero si pudiendo infectarse).
	- Conteo de sanos, infectados, y particulas aísladas.
	- Muro vertical.

Para ejecutar:

	transmision(individuos, contagionProbability, tiempoRecuperacion)

individuos-> número de individuos a generar.
contagionProbability-> probabilidad de contagio, entre 0 y 1.
tiempoRecuperacion-> segundos desde que se infectó un individuo hasta su recuperación.

NOTA:
Para detener el programa usar Ctrl-C o cerrar dos veces la ventana de gráficos.