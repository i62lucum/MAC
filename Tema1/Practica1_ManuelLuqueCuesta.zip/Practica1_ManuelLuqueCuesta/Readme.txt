REALIZADO POR  ##### Manuel Luque Cuesta ######

La función principal es "hipoteca" que recibe como parámetros:
%   x_inf: extremo inferior del intervalo para biparticion
%   x_sup: extremo superior del intervalo para biparticion
%   x0: punto inicial de busqueda para NewtonRaphson
%   AA: valor a pagar por periodo
%   nn: numero de periodos
%   CC: cantidad solicitar mediante la hipoteca

En el "Documento.pdf" se encuentra todo lo relativo al estudio y los resultados obtenidos.