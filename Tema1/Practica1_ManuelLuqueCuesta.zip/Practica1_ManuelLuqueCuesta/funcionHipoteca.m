function y=funcionHipoteca(x)

global A n C;

y=A*(1-(1+x)^-n)-C*x;



end